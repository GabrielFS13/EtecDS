﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub CmdVerificar_Click(sender As Object, e As EventArgs) Handles CmdVerificar.Click
        Dim valor As Integer = 0
        LblSTATUS.Text = ""
        valor = txtValor.Text
        If (valor = 10) Then
            LblSTATUS.Text = "Você digitou 10"
        Else
            LblSTATUS.Text = "Não quero"
        End If
        txtValor.Focus()
        txtValor.Text = ""
    End Sub
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtValor = New System.Windows.Forms.TextBox()
        Me.LblSTATUS = New System.Windows.Forms.Label()
        Me.CmdVerificar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(86, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(247, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Entre com um valor"
        '
        'txtValor
        '
        Me.txtValor.Location = New System.Drawing.Point(93, 87)
        Me.txtValor.Name = "txtValor"
        Me.txtValor.Size = New System.Drawing.Size(227, 20)
        Me.txtValor.TabIndex = 1
        '
        'LblSTATUS
        '
        Me.LblSTATUS.AutoSize = True
        Me.LblSTATUS.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblSTATUS.ForeColor = System.Drawing.Color.Blue
        Me.LblSTATUS.Location = New System.Drawing.Point(166, 129)
        Me.LblSTATUS.Name = "LblSTATUS"
        Me.LblSTATUS.Size = New System.Drawing.Size(62, 25)
        Me.LblSTATUS.TabIndex = 2
        Me.LblSTATUS.Text = "Status"
        '
        'CmdVerificar
        '
        Me.CmdVerificar.BackColor = System.Drawing.Color.White
        Me.CmdVerificar.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CmdVerificar.Location = New System.Drawing.Point(428, 108)
        Me.CmdVerificar.Name = "CmdVerificar"
        Me.CmdVerificar.Size = New System.Drawing.Size(89, 46)
        Me.CmdVerificar.TabIndex = 3
        Me.CmdVerificar.Text = "Verificar"
        Me.CmdVerificar.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOrange
        Me.ClientSize = New System.Drawing.Size(555, 262)
        Me.Controls.Add(Me.CmdVerificar)
        Me.Controls.Add(Me.LblSTATUS)
        Me.Controls.Add(Me.txtValor)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Exercicio2_Gabriel"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtValor As TextBox
    Friend WithEvents LblSTATUS As Label
    Friend WithEvents CmdVerificar As Button
End Class

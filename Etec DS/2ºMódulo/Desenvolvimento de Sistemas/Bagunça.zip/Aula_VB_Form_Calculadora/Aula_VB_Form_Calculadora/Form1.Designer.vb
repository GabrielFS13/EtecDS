﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.V1 = New System.Windows.Forms.TextBox()
        Me.V2 = New System.Windows.Forms.TextBox()
        Me.Res = New System.Windows.Forms.TextBox()
        Me.btn_soma = New System.Windows.Forms.Button()
        Me.btn_multi = New System.Windows.Forms.Button()
        Me.btn_divi = New System.Windows.Forms.Button()
        Me.btn_sub = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label1.Location = New System.Drawing.Point(254, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(322, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "REALIZAR OPERAÇÕES"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(140, 127)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 31)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Insira o valor 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(140, 172)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(156, 31)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Insira o valor 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(184, 311)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 31)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Resultado"
        '
        'V1
        '
        Me.V1.Location = New System.Drawing.Point(302, 138)
        Me.V1.Name = "V1"
        Me.V1.Size = New System.Drawing.Size(125, 20)
        Me.V1.TabIndex = 4
        '
        'V2
        '
        Me.V2.Location = New System.Drawing.Point(302, 172)
        Me.V2.Name = "V2"
        Me.V2.Size = New System.Drawing.Size(125, 20)
        Me.V2.TabIndex = 5
        '
        'Res
        '
        Me.Res.Location = New System.Drawing.Point(302, 322)
        Me.Res.Name = "Res"
        Me.Res.Size = New System.Drawing.Size(137, 20)
        Me.Res.TabIndex = 6
        '
        'btn_soma
        '
        Me.btn_soma.Location = New System.Drawing.Point(215, 249)
        Me.btn_soma.Name = "btn_soma"
        Me.btn_soma.Size = New System.Drawing.Size(79, 23)
        Me.btn_soma.TabIndex = 7
        Me.btn_soma.Text = "Somar"
        Me.btn_soma.UseVisualStyleBackColor = True
        '
        'btn_multi
        '
        Me.btn_multi.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_multi.FlatAppearance.BorderSize = 0
        Me.btn_multi.Location = New System.Drawing.Point(302, 249)
        Me.btn_multi.Name = "btn_multi"
        Me.btn_multi.Size = New System.Drawing.Size(75, 23)
        Me.btn_multi.TabIndex = 8
        Me.btn_multi.Text = "Multiplicar"
        Me.btn_multi.UseVisualStyleBackColor = False
        '
        'btn_divi
        '
        Me.btn_divi.Location = New System.Drawing.Point(383, 249)
        Me.btn_divi.Name = "btn_divi"
        Me.btn_divi.Size = New System.Drawing.Size(75, 23)
        Me.btn_divi.TabIndex = 9
        Me.btn_divi.Text = "Dividir"
        Me.btn_divi.UseVisualStyleBackColor = True
        '
        'btn_sub
        '
        Me.btn_sub.Location = New System.Drawing.Point(464, 249)
        Me.btn_sub.Name = "btn_sub"
        Me.btn_sub.Size = New System.Drawing.Size(75, 23)
        Me.btn_sub.TabIndex = 10
        Me.btn_sub.Text = "Subtrair"
        Me.btn_sub.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(759, 475)
        Me.Controls.Add(Me.btn_sub)
        Me.Controls.Add(Me.btn_divi)
        Me.Controls.Add(Me.btn_multi)
        Me.Controls.Add(Me.btn_soma)
        Me.Controls.Add(Me.Res)
        Me.Controls.Add(Me.V2)
        Me.Controls.Add(Me.V1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Calculadora"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents V1 As TextBox
    Friend WithEvents V2 As TextBox
    Friend WithEvents Res As TextBox
    Friend WithEvents btn_soma As Button
    Friend WithEvents btn_multi As Button
    Friend WithEvents btn_divi As Button
    Friend WithEvents btn_sub As Button
End Class

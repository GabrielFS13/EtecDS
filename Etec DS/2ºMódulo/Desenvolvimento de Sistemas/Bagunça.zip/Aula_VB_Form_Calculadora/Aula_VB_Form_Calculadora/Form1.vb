﻿Public Class Form1
    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles Res.TextChanged

    End Sub

    Private Sub btn_soma_Click(sender As Object, e As EventArgs) Handles btn_soma.Click
        REM V1 é o nome do textBox e o .text é para pegar o valor do TextBox 
        Dim N1, N2, resultado As Double
        N1 = V1.Text
        N2 = V2.Text
        resultado = N1 + N2
        Res.Text = resultado
    End Sub

    Private Sub btn_multi_Click(sender As Object, e As EventArgs) Handles btn_multi.Click
        REM V1 é o nome do textBox e o .text é para pegar o valor do TextBox 
        Dim N1, N2, resultado As Double
        N1 = V1.Text
        N2 = V2.Text
        resultado = N1 * N2
        Res.Text = resultado
    End Sub

    Private Sub btn_divi_Click(sender As Object, e As EventArgs) Handles btn_divi.Click
        REM V1 é o nome do textBox e o .text é para pegar o valor do TextBox 
        Dim N1, N2, resultado As Double
        N1 = V1.Text
        N2 = V2.Text
        resultado = N1 / N2
        Res.Text = resultado
    End Sub

    Private Sub btn_sub_Click(sender As Object, e As EventArgs) Handles btn_sub.Click
        REM V1 é o nome do textBox e o .text é para pegar o valor do TextBox 
        Dim N1, N2, resultado As Double
        N1 = V1.Text
        N2 = V2.Text
        resultado = N1 + -N2
        Res.Text = resultado
    End Sub
End Class

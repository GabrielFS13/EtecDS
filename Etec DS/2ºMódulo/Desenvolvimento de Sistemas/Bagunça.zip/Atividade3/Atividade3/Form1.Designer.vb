﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TXT_HOMEM = New System.Windows.Forms.TextBox()
        Me.TXT_CARRO = New System.Windows.Forms.TextBox()
        Me.btn_combina = New System.Windows.Forms.Button()
        Me.btn_limpa = New System.Windows.Forms.Button()
        Me.btn_sair = New System.Windows.Forms.Button()
        Me.lblCasa = New System.Windows.Forms.Label()
        Me.lblGaragem = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(66, 66)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(65, 23)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Homem"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(82, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Carro"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(300, 188)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Garagem"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(66, 188)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 23)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Casa"
        '
        'TXT_HOMEM
        '
        Me.TXT_HOMEM.Location = New System.Drawing.Point(154, 71)
        Me.TXT_HOMEM.Name = "TXT_HOMEM"
        Me.TXT_HOMEM.Size = New System.Drawing.Size(100, 20)
        Me.TXT_HOMEM.TabIndex = 4
        '
        'TXT_CARRO
        '
        Me.TXT_CARRO.Location = New System.Drawing.Point(154, 121)
        Me.TXT_CARRO.Name = "TXT_CARRO"
        Me.TXT_CARRO.Size = New System.Drawing.Size(100, 20)
        Me.TXT_CARRO.TabIndex = 5
        '
        'btn_combina
        '
        Me.btn_combina.BackColor = System.Drawing.Color.White
        Me.btn_combina.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_combina.ForeColor = System.Drawing.Color.Black
        Me.btn_combina.Location = New System.Drawing.Point(46, 271)
        Me.btn_combina.Name = "btn_combina"
        Me.btn_combina.Size = New System.Drawing.Size(85, 35)
        Me.btn_combina.TabIndex = 8
        Me.btn_combina.Text = "Combinar"
        Me.btn_combina.UseVisualStyleBackColor = False
        '
        'btn_limpa
        '
        Me.btn_limpa.BackColor = System.Drawing.Color.White
        Me.btn_limpa.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_limpa.Location = New System.Drawing.Point(192, 271)
        Me.btn_limpa.Name = "btn_limpa"
        Me.btn_limpa.Size = New System.Drawing.Size(77, 35)
        Me.btn_limpa.TabIndex = 9
        Me.btn_limpa.Text = "Limpar"
        Me.btn_limpa.UseVisualStyleBackColor = False
        '
        'btn_sair
        '
        Me.btn_sair.BackColor = System.Drawing.Color.White
        Me.btn_sair.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_sair.Location = New System.Drawing.Point(335, 271)
        Me.btn_sair.Name = "btn_sair"
        Me.btn_sair.Size = New System.Drawing.Size(83, 35)
        Me.btn_sair.TabIndex = 10
        Me.btn_sair.Text = "Sair"
        Me.btn_sair.UseVisualStyleBackColor = False
        '
        'lblCasa
        '
        Me.lblCasa.AutoSize = True
        Me.lblCasa.Location = New System.Drawing.Point(67, 221)
        Me.lblCasa.Name = "lblCasa"
        Me.lblCasa.Size = New System.Drawing.Size(0, 13)
        Me.lblCasa.TabIndex = 12
        '
        'lblGaragem
        '
        Me.lblGaragem.AutoSize = True
        Me.lblGaragem.Location = New System.Drawing.Point(316, 221)
        Me.lblGaragem.Name = "lblGaragem"
        Me.lblGaragem.Size = New System.Drawing.Size(0, 13)
        Me.lblGaragem.TabIndex = 13
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumPurple
        Me.ClientSize = New System.Drawing.Size(490, 350)
        Me.Controls.Add(Me.lblGaragem)
        Me.Controls.Add(Me.lblCasa)
        Me.Controls.Add(Me.btn_sair)
        Me.Controls.Add(Me.btn_limpa)
        Me.Controls.Add(Me.btn_combina)
        Me.Controls.Add(Me.TXT_CARRO)
        Me.Controls.Add(Me.TXT_HOMEM)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.label1)
        Me.Name = "Form1"
        Me.Text = "Combinação"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TXT_HOMEM As TextBox
    Friend WithEvents TXT_CARRO As TextBox
    Friend WithEvents btn_combina As Button
    Friend WithEvents btn_limpa As Button
    Friend WithEvents btn_sair As Button
    Friend WithEvents lblCasa As Label
    Friend WithEvents lblGaragem As Label
End Class

﻿Public Class Form1
    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_combina.Click

        lblCasa.Text = TXT_HOMEM.Text
        lblGaragem.Text = TXT_CARRO.Text

    End Sub

    Private Sub btn_limpa_Click(sender As Object, e As EventArgs) Handles btn_limpa.Click

        TXT_CARRO.Text = ""
        TXT_HOMEM.Text = ""
        lblGaragem.Text = ""
        lblCasa.Text = ""

    End Sub

    Private Sub btn_sair_Click(sender As Object, e As EventArgs) Handles btn_sair.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class

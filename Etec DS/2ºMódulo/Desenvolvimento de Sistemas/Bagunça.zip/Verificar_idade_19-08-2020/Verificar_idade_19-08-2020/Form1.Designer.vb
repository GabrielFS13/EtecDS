﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cmdmaiormenor
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MaiorMenor = New System.Windows.Forms.Button()
        Me.Lbldi = New System.Windows.Forms.Label()
        Me.Lblresultado = New System.Windows.Forms.TextBox()
        Me.lbltextoresultado = New System.Windows.Forms.Label()
        Me.Txtidade = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'MaiorMenor
        '
        Me.MaiorMenor.Location = New System.Drawing.Point(171, 171)
        Me.MaiorMenor.Name = "MaiorMenor"
        Me.MaiorMenor.Size = New System.Drawing.Size(99, 35)
        Me.MaiorMenor.TabIndex = 0
        Me.MaiorMenor.Text = "Maior?"
        Me.MaiorMenor.UseVisualStyleBackColor = True
        '
        'Lbldi
        '
        Me.Lbldi.AutoSize = True
        Me.Lbldi.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbldi.Location = New System.Drawing.Point(134, 28)
        Me.Lbldi.Name = "Lbldi"
        Me.Lbldi.Size = New System.Drawing.Size(170, 31)
        Me.Lbldi.TabIndex = 1
        Me.Lbldi.Text = "Digite sua idade"
        '
        'Lblresultado
        '
        Me.Lblresultado.Location = New System.Drawing.Point(113, 317)
        Me.Lblresultado.Name = "Lblresultado"
        Me.Lblresultado.Size = New System.Drawing.Size(217, 20)
        Me.Lblresultado.TabIndex = 2
        '
        'lbltextoresultado
        '
        Me.lbltextoresultado.AutoSize = True
        Me.lbltextoresultado.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltextoresultado.Location = New System.Drawing.Point(178, 274)
        Me.lbltextoresultado.Name = "lbltextoresultado"
        Me.lbltextoresultado.Size = New System.Drawing.Size(92, 25)
        Me.lbltextoresultado.TabIndex = 3
        Me.lbltextoresultado.Text = "Resultado"
        '
        'Txtidade
        '
        Me.Txtidade.Location = New System.Drawing.Point(153, 75)
        Me.Txtidade.Name = "Txtidade"
        Me.Txtidade.Size = New System.Drawing.Size(140, 20)
        Me.Txtidade.TabIndex = 4
        '
        'Cmdmaiormenor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(434, 450)
        Me.Controls.Add(Me.Txtidade)
        Me.Controls.Add(Me.lbltextoresultado)
        Me.Controls.Add(Me.Lblresultado)
        Me.Controls.Add(Me.Lbldi)
        Me.Controls.Add(Me.MaiorMenor)
        Me.Name = "Cmdmaiormenor"
        Me.Text = "Maior ou Menor?"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MaiorMenor As Button
    Friend WithEvents Lbldi As Label
    Friend WithEvents Lblresultado As TextBox
    Friend WithEvents lbltextoresultado As Label
    Friend WithEvents Txtidade As TextBox
End Class

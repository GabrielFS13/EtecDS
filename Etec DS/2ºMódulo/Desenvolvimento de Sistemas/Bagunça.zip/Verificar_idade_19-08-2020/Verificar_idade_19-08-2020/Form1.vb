﻿Public Class Cmdmaiormenor
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Lbldi.Click

    End Sub

    Private Sub MaiorMenor_Click(sender As Object, e As EventArgs) Handles MaiorMenor.Click

        Dim idade As Integer
        idade = CInt(Txtidade.Text)

        If idade = 18 Then
            Lblresultado.Text = "Você é maior, pois tem 18 anos."
        Else
            If idade < 18 Then
                Lblresultado.Text = "Você é menor, pois ainda não tem 18 anos."
            Else
                Lblresultado.Text = "Você é maior,pois tem " & idade & " anos."

            End If
        End If

    End Sub

    Private Sub lbltextoresultado_Click(sender As Object, e As EventArgs) Handles lbltextoresultado.Click

    End Sub
End Class

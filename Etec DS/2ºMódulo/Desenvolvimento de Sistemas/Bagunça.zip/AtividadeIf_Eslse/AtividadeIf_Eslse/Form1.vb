﻿Public Class Form1
    Private Sub NameBox_TextChanged(sender As Object, e As EventArgs) Handles NameBox.TextChanged

    End Sub

    Private Sub BTN_ENTER_Click(sender As Object, e As EventArgs) Handles BTN_ENTER.Click
        Dim nome As Double

        If NameBox.Text = "Israel" Then
            NameBox.Text = nome
            MsgBox("Bem Vindo Israel!")
        ElseIf NameBox.Text = "Paulo" Then
            MsgBox("Bem Vindo Paulo!")
        Else
            MsgBox("O nome " & NameBox.Text & " não está no sistema.")
        End If
    End Sub
End Class
